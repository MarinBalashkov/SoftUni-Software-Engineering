﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_HospitalDatabase.Data
{
    public static class Configuration
    {
        public const string ConnectionString = "Server=DESKTOP-8R5RNRE\\SQLEXPRESS;Database=HospitalDatabase;Integrated Security=True;";
    }
}
